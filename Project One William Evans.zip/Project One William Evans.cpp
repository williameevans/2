// William Evans SNHU Project One
#include <iostream>
#include <iomanip>
#include <limits>

class Clock {
private:
    int hour;
    int minute;
    int second;

public:
    Clock();  // Constructor to initialize the clock
    void setTime(int h, int m, int s);  // Function to set time
    void display12HourClock() const;  // Function to display 12-hour clock
    void display24HourClock() const;  // Function to display 24-hour clock
};

Clock::Clock() {
    // Implement based on your system time or default values
    hour = 12;
    minute = 0;
    second = 0;
}

void Clock::setTime(int h, int m, int s) {
    // Implement validation if needed
    hour = (h >= 0 && h < 24) ? h : 0;
    minute = (m >= 0 && m < 60) ? m : 0;
    second = (s >= 0 && s < 60) ? s : 0;
}

void Clock::display12HourClock() const {
    std::cout << std::setfill('0') << std::setw(2) << hour % 12 << ":"
              << std::setw(2) << minute << ":" << std::setw(2) << second
              << (hour < 12 ? " AM" : " PM") << std::endl;
}

void Clock::display24HourClock() const {
    std::cout << std::setfill('0') << std::setw(2) << hour << ":"
              << std::setw(2) << minute << ":" << std::setw(2) << second
              << std::endl;
}

int main() {
    Clock clock;

    // Allow user input to set the time with error handling
    int h, m, s;
    do {
        std::cout << "Enter hour (0-23): ";
        std::cin >> h;
    } while (h < 0 || h >= 24);

    do {
        std::cout << "Enter minute (0-59): ";
        std::cin >> m;
    } while (m < 0 || m >= 60);

    do {
        std::cout << "Enter second (0-59): ";
        std::cin >> s;
    } while (s < 0 || s >= 60);

    clock.setTime(h, m, s);

    // Display both clocks
    std::cout << "12-Hour Clock: ";
    clock.display12HourClock();

    std::cout << "24-Hour Clock: ";
    clock.display24HourClock();

    return 0;
}